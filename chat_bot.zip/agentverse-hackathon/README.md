# Onboarding Chatbot

An AI-powered chatbot that answers employee onboarding questions using company knowledge base documents.

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run via CLI

```bash
python main.py "How do I reset my password?"
```

### 3. Run API Server

```bash
# Start the server
uvicorn backend.api.main:app --reload --port 8000
```

Then open `frontend/index.html` in your browser or access the API at `http://localhost:8000`

## Features

- **Document Search**: Searches company knowledge base for relevant information
- **AI-Powered Answers**: Uses OpenAI to generate helpful responses
- **Safety Checks**: Automatically blocks unsafe queries
- **Topic Classification**: Routes questions to appropriate departments (IT, HR, Security, etc.)
- **Tracing**: Full request tracing available in `backend/logs/traces.jsonl`

## API Endpoints

- `POST /chat` - Chat with the bot
- `GET /trace/{request_id}` - View request trace
- `GET /health` - Health check

## Configuration

The OpenAI API key is configured in `backend/agent/config.py`. No additional setup needed.

## Project Structure

```
agentverse-hackathon/
├── backend/
│   ├── agent/          # Core agent logic
│   ├── api/            # FastAPI endpoints
│   ├── data/           # Knowledge base documents
│   └── logs/           # Trace logs
├── frontend/           # Web interface
└── main.py            # CLI entry point
```
