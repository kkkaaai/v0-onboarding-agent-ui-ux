# Minimal Setup Guide for ANAM.ai Integration

## ✅ What Was Simplified

1. **Tracing is now optional** - System works even if tracing fails
2. **FAISS is optional** - Always falls back to smart mock
3. **Error handling** - Never crashes, always returns valid JSON
4. **Startup** - Doesn't require FAISS index to start
5. **Gap logging** - Optional, fails gracefully

## 🚀 Minimal Setup (3 Steps)

### Step 1: Environment Setup
```bash
# Create backend/.env
OPENAI_API_KEY=your_key_here
MODEL_NAME=gpt-4o-mini
TEMPERATURE=0.2
```

### Step 2: Ensure metadata.json exists
```bash
# If you don't have vector index, ensure at least:
# backend/vector_store/metadata.json exists with chunks
```

### Step 3: Start Server
```bash
cd backend
python run_server.py
# Or: uvicorn api.main:app --port 8787
```

**That's it!** The server will:
- ✅ Start even without FAISS index
- ✅ Use mock search if FAISS missing
- ✅ Work with ANAM.ai via ngrok
- ✅ Never crash (always returns JSON)

## 🔧 ngrok Setup

```bash
# In separate terminal
ngrok http 8787

# Copy URL (e.g., https://abcd1234.ngrok.io)
# Update anam_config.json URLs
```

## ✅ What Works Without Setup

- ✅ Document search (uses mock if FAISS missing)
- ✅ Ticket creation
- ✅ Safety checks
- ✅ Topic classification
- ✅ Error handling (graceful failures)

## ⚠️ What Needs Setup

- ❌ FAISS vector index (optional - uses mock without it)
- ❌ Tracing logs (optional - works without logging)
- ❌ Gap analysis (optional - works without logging)

## 🎯 Minimal Requirements

**Absolute minimum to run:**
1. `backend/.env` with `OPENAI_API_KEY`
2. `backend/vector_store/metadata.json` (for mock fallback)
3. Server running on port 8787
4. ngrok tunnel pointing to 8787

Everything else is optional and has fallbacks!

