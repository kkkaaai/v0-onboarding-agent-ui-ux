#!/bin/bash
# Simple shell script to run the backend server
# Make sure you're in the project root directory when running this
python backend/run_server.py

