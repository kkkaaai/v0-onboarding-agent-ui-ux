from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
from datetime import datetime
import uuid

class SourceRef(BaseModel):
    source: str
    page: Optional[int] = None
    score: Optional[float] = None

class StepEvent(BaseModel):
    step_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    start_ts: datetime
    end_ts: Optional[datetime] = None
    status: str = "ok"
    latency_ms: Optional[int] = None
    input_preview: Optional[str] = None
    output_preview: Optional[str] = None
    sources: List[SourceRef] = []
    error_type: Optional[str] = None
    error_message: Optional[str] = None

class TraceRecord(BaseModel):
    request_id: str
    session_id: str
    user_id: str
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    start_ts: datetime
    end_ts: Optional[datetime] = None
    steps: List[StepEvent] = []
    route: Optional[str] = None
    safety_verdict: Optional[str] = None
    final_status: str = "ok"
    root_cause: Optional[str] = None
    config: Dict[str, Any] = {}

