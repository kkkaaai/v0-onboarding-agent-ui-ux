import os, json
from typing import Iterable

LOG_PATH = "backend/logs/traces.jsonl"
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

def append_trace(record: dict):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

def read_trace(request_id: str) -> Iterable[dict]:
    if not os.path.exists(LOG_PATH):
        return []
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            rec = json.loads(line)
            if rec.get("request_id") == request_id:
                yield rec

