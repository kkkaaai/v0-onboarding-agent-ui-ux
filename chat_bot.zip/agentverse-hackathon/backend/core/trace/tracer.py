from datetime import datetime
from backend.core.trace.schemas import TraceRecord, StepEvent, SourceRef
from backend.core.trace.storage import append_trace

class Tracer:
    def __init__(self, request_id, session_id, user_id, config):
        self.rec = TraceRecord(
            request_id=request_id,
            session_id=session_id,
            user_id=user_id,
            start_ts=datetime.utcnow(),
            config=config
        )

    def start_step(self, name):
        step = StepEvent(name=name, start_ts=datetime.utcnow())
        self.rec.steps.append(step)
        return step

    def finish_step(self, step, input_preview=None, output_preview=None,
                    status="ok", sources=None, error_type=None, error_message=None):
        step.end_ts = datetime.utcnow()
        step.latency_ms = int((step.end_ts - step.start_ts).total_seconds() * 1000)
        step.input_preview = (input_preview or "")[:120]
        step.output_preview = (output_preview or "")[:120]
        step.status = status
        step.sources = sources or []
        step.error_type = error_type
        step.error_message = error_message

    def set_route(self, route): self.rec.route = route
    def set_safety(self, verdict): self.rec.safety_verdict = verdict

    def end(self, final_status="ok", root_cause=None):
        self.rec.end_ts = datetime.utcnow()
        self.rec.final_status = final_status
        self.rec.root_cause = root_cause
        append_trace(self.rec.model_dump(mode='json'))
