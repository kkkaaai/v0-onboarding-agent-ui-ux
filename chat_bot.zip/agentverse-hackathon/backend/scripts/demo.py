#!/usr/bin/env python3
"""
Demo script to showcase all features of the onboarding agent.
Run this after starting the server to see everything in action.
"""
import requests
import json
import time

BASE_URL = "http://localhost:8787"

def print_section(title):
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def demo_search(query, user_id="demo_user"):
    """Demonstrate document search with RAG."""
    print_section("DOCUMENT SEARCH DEMO")
    print(f"Query: {query}")
    print(f"User: {user_id}")
    
    response = requests.post(
        f"{BASE_URL}/tools/search_docs",
        json={"query": query, "user_id": user_id}
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"\n✅ Success!")
        print(f"Topic: {data.get('topic')}")
        print(f"Safety: {data.get('safety')}")
        print(f"Confidence: {data.get('confidence')}")
        print(f"\nAnswer:\n  {data.get('answer', 'N/A')}")
        print(f"\nCitations ({len(data.get('citations', []))}):")
        for i, cit in enumerate(data.get('citations', [])[:3], 1):
            print(f"  {i}. {cit.get('source', 'unknown')} (score: {cit.get('score', 0):.2f})")
        
        # Show trace
        request_id = data.get('request_id')
        if request_id:
            print(f"\n📊 View trace: GET {BASE_URL}/trace/{request_id}")
        
        return data.get('request_id')
    else:
        print(f"❌ Error: {response.status_code} - {response.text}")
        return None

def demo_ticket(description, user_id="demo_user"):
    """Demonstrate ticket creation."""
    print_section("TICKET CREATION DEMO")
    print(f"Description: {description}")
    print(f"User: {user_id}")
    
    response = requests.post(
        f"{BASE_URL}/tools/create_ticket",
        json={"params": {"description": description}, "user_id": user_id}
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"\n✅ Ticket Created!")
        print(f"Ticket ID: {data.get('ticket_id')}")
        print(f"Status: {data.get('status')}")
        print(f"Topic: {data.get('topic')}")
        print(f"Assigned to: {data.get('assigned_to', {}).get('name')} ({data.get('assigned_to', {}).get('email')})")
        print(f"Safety: {data.get('safety')}")
        
        # Show trace
        request_id = data.get('request_id')
        if request_id:
            print(f"\n📊 View trace: GET {BASE_URL}/trace/{request_id}")
        
        return data.get('request_id')
    else:
        print(f"❌ Error: {response.status_code} - {response.text}")
        return None

def demo_trace(request_id):
    """Show trace information for a request."""
    print_section(f"TRACE: {request_id[:8]}...")
    
    response = requests.get(f"{BASE_URL}/trace/{request_id}")
    
    if response.status_code == 200:
        trace = response.json()
        print(f"Request ID: {trace.get('request_id')}")
        print(f"User ID: {trace.get('user_id')}")
        print(f"Status: {trace.get('final_status')}")
        print(f"Route: {trace.get('route')}")
        print(f"Safety: {trace.get('safety_verdict')}")
        print(f"\nSteps ({len(trace.get('steps', []))}):")
        for i, step in enumerate(trace.get('steps', []), 1):
            print(f"  {i}. {step.get('name')}")
            print(f"     Status: {step.get('status')}, Latency: {step.get('latency_ms', 0)}ms")
            if step.get('output_preview'):
                print(f"     Output: {step.get('output_preview')[:60]}...")
    else:
        print(f"❌ Error: {response.status_code} - {response.text}")

def demo_safety():
    """Test safety system with unsafe queries."""
    print_section("SAFETY SYSTEM DEMO")
    
    unsafe_queries = [
        "delete all files",
        "how much is my salary",
        "normal question about email"
    ]
    
    for query in unsafe_queries:
        print(f"\nQuery: {query}")
        response = requests.post(
            f"{BASE_URL}/tools/search_docs",
            json={"query": query, "user_id": "demo_user"}
        )
        if response.status_code == 200:
            data = response.json()
            safety = data.get('safety', 'unknown')
            if safety == 'deny':
                print(f"  🚫 BLOCKED: {data.get('error')}")
            elif safety == 'needs_approval':
                print(f"  ⚠️  REQUIRES APPROVAL: {data.get('safety')}")
            else:
                print(f"  ✅ ALLOWED: {data.get('answer', '')[:50]}...")

def main():
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║     ONBOARDING AGENT - HACKATHON DEMO                    ║
    ╚═══════════════════════════════════════════════════════════╝
    
    Make sure the server is running on http://localhost:8787
    """)
    
    # Health check
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            health = response.json()
            print(f"✅ Server is running! Model: {health.get('model')}, KB: {health.get('kb_version')}")
        else:
            print("❌ Server health check failed!")
            return
    except Exception as e:
        print(f"❌ Cannot connect to server: {e}")
        print("   Make sure to start the server first: python backend/run_server.py")
        return
    
    time.sleep(1)
    
    # Demo 1: Document Search
    request_id1 = demo_search("How do I reset my password?", "demo_user_1")
    time.sleep(1)
    
    # Demo 2: Different query
    request_id2 = demo_search("What are the annual leave policies?", "demo_user_2")
    time.sleep(1)
    
    # Demo 3: Ticket Creation
    request_id3 = demo_ticket("I need VPN access for remote work", "demo_user_1")
    time.sleep(1)
    
    # Demo 4: Safety System
    demo_safety()
    time.sleep(1)
    
    # Demo 5: View Traces
    if request_id1:
        demo_trace(request_id1)
    time.sleep(1)
    
    if request_id3:
        demo_trace(request_id3)
    
    print_section("DEMO COMPLETE")
    print("""
    🎉 All features demonstrated!
    
    Features shown:
    ✅ RAG-based document search
    ✅ Answer generation with citations
    ✅ Topic classification
    ✅ Confidence scoring
    ✅ Safety checks
    ✅ Ticket creation with routing
    ✅ Request tracing
    
    Next steps:
    - Check backend/logs/traces.jsonl for all traces
    - Check backend/logs/knowledge_gaps.json for low-confidence queries
    - Use the API endpoints with your own queries!
    """)

if __name__ == "__main__":
    main()

