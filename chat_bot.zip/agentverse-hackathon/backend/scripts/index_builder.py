import os, json, pickle
from backend.agent.retriever import KnowledgeBase

if __name__ == "__main__":
    os.makedirs("backend/vector_store", exist_ok=True)
    kb = KnowledgeBase()
    print("Building FAISS vector index from backend/data...")

    db = kb.build_index(data_dir="backend/data")

    # Verify index
    size = len(db.index_to_docstore_id)
    dim = db.index.d
    print(f"✅ Index built successfully: {size} vectors, dim={dim}")

    # Save again manually to ensure metadata consistency
    meta = {"size": size, "embedding_dim": dim}
    with open(os.path.join("backend/vector_store", "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    with open(os.path.join("backend/vector_store", "faiss_index.pkl"), "wb") as f:
        pickle.dump(db, f)

    print("💾 Saved faiss_index.pkl + metadata.json")
