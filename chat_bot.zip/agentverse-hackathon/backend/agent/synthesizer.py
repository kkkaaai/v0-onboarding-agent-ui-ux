from openai import OpenAI  # type: ignore
from backend.agent.config import OPENAI_API_KEY, MODEL_NAME, TEMPERATURE

def _mock_answer(query: str, context: str):
    """
    Professional, brief, and actionable offline fallback.
    Heuristic routing to IT/HR/Security/Engineering with steps.
    """
    q = (query or '').lower()
    if any(k in q for k in ['vpn', 'laptop', 'password', 'email', 'login', 'reset']):
        dept = 'IT'
        guidance = (
            "This appears to be an IT onboarding request. "
            "1) Visit the IT portal. 2) Use the password reset or device setup guide. "
            "3) If blocked, contact the IT Helpdesk via the internal directory."
        )
    elif any(k in q for k in ['payroll', 'leave', 'benefit', 'policy', 'vacation']):
        dept = 'HR'
        guidance = (
            "This relates to HR. Review the HR onboarding handbook and the leave/benefits section. "
            "If something is unclear, raise it with HR using the company directory."
        )
    elif any(k in q for k in ['badge', 'access card', 'security training', '2fa']):
        dept = 'Security'
        guidance = (
            "This concerns Security. Complete mandatory security training and follow the ID badge instructions."
        )
    else:
        dept = 'General'
        guidance = (
            "I’ve provided a concise answer based on available onboarding materials. "
            "Refer to the knowledge base links and follow the documented steps."
        )
    answer = f"Department: {dept}. " + guidance
    if context.strip():
        answer += "\n\nRelevant context:\n" + context[:600]
    return answer


# Initialize client once
_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

def synthesize_answer(query: str, results):
    """Generate answer from retrieved documents, safely handling proxy / SDK responses."""
    # Offline fallback if key not present
    if not OPENAI_API_KEY:
        context = "\n\n".join([d.page_content for d, _ in results]) if results else ""
        return _mock_answer(query, context)

    from traceback import format_exc

    # If no client (no key), fallback (already handled above)
    if _client is None:
        context = "\n\n".join([d.page_content for d, _ in results]) if results else ""
        return _mock_answer(query, context)

    # Build context
    context = "\n\n".join([d.page_content for d, _ in results]) if results else ""
    prompt = f"""You are a corporate onboarding assistant.
Answer ONLY using the context below. If unsure, say you’re not certain and suggest HR/IT contacts.

Context:
{context}

Question: {query}
"""

    try:
        resp = _client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=TEMPERATURE,
        )

        # --- Proxy HTML detection ---
        if isinstance(resp, str) and resp.strip().lower().startswith("<!doctype html"):
            print("⚠️ HTML response detected — proxy returned web page instead of JSON. Falling back to offline mode.")
            return _mock_answer(query, context)
        # -----------------------------

        # ✅ Handle different SDK response types
        if isinstance(resp, str):
            return resp
        elif isinstance(resp, dict):
            return resp.get("choices", [{}])[0].get("message", {}).get("content", "")
        elif hasattr(resp, "choices"):
            return resp.choices[0].message.content
        else:
            print("⚠️ Unknown response type:", type(resp))
            return str(resp)

    except Exception as e:
        print("❌ Error in synthesize_answer:", e)
        print(format_exc())
        return f"Error during synthesis: {e}"