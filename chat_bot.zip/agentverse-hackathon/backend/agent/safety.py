def check_safety(query: str, action: str = None):
    forbidden = ["delete", "shutdown", "execute", "format"]
    if any(f in query.lower() for f in forbidden):
        return "deny", "Potentially unsafe action detected"
    if "salary" in query.lower():
        return "needs_approval", "Sensitive financial info"
    return "allow", None
