def classify_route(query: str) -> str:
    q = query.lower()
    if any(k in q for k in ["password", "vpn", "email", "it support"]):
        return "IT"
    elif any(k in q for k in ["leave", "holiday", "payroll", "benefit"]):
        return "HR"
    elif any(k in q for k in ["access", "data policy", "security"]):
        return "Security"
    elif any(k in q for k in ["code", "repo", "deploy"]):
        return "Engineering"
    return "General"
