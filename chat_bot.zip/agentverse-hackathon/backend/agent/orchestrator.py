# agent/orchestrator.py
import uuid
from backend.skills.docs_navigator import answer_with_citations
from backend.skills.knowledge_gap import tag_query, confidence_score
from backend.skills.people_lookup import find_contact
from backend.agent.safety import check_safety
from backend.agent.gap_analyzer import log_gap
from backend.core.trace.tracer import Tracer
from backend.core.trace.schemas import SourceRef

def run_docs_search(query: str, user_id: str):
    rid = str(uuid.uuid4())
    
    # Initialize tracer (fails gracefully if there's an issue)
    tracer = None
    try:
        tracer = Tracer(
            request_id=rid,
            session_id=f"session_{user_id}",
            user_id=user_id,
            config={"model": "gpt-4o-mini", "kb_version": "2025-01-01"}
        )
    except Exception:
        pass  # Tracing is optional, continue without it
    
    try:
        # Step 1: Topic Classification
        topic = tag_query(query)
        # Upsert minimal profile in Anam for transparency
        try:
            upsert_user_profile(user_id, {"last_topic": topic})
        except Exception:
            pass
        if tracer:
            topic_step = tracer.start_step("topic_classification")
            tracer.finish_step(topic_step, input_preview=query[:120], output_preview=topic, status="ok")
            tracer.set_route(topic)
        
        # Step 2: Safety Check
        safety_status, safety_message = check_safety(query)
        if tracer:
            safety_step = tracer.start_step("safety_check")
            tracer.finish_step(
                safety_step,
                input_preview=query[:120],
                output_preview=f"{safety_status}: {safety_message or 'OK'}",
                status="ok"
            )
            tracer.set_safety(safety_status)
        
        # Block unsafe queries
        if safety_status == "deny":
            if tracer:
                tracer.end(final_status="denied", root_cause=safety_message)
            return {
                "request_id": rid,
                "user_id": user_id,
                "status": "denied",
                "error": safety_message,
                "topic": topic,
                "safety": safety_status,
                "citations": []
            }
        
        # Step 3: Document Search
        if tracer:
            search_step = tracer.start_step("vector_search")
        answer, citations = answer_with_citations(query)
        if tracer:
            tracer.finish_step(
                search_step,
                input_preview=query[:120],
                output_preview=f"Found {len(citations)} relevant chunks",
                status="ok",
                sources=[SourceRef(source=c["source"], score=c.get("score")) for c in citations]
            )
        
        # Step 4: Confidence Scoring (based on search quality)
        if citations:
            # Average of top citation scores, normalized
            avg_score = sum(c.get("score", 0.5) for c in citations) / len(citations)
            conf = min(1.0, max(0.1, avg_score))  # Clamp between 0.1 and 1.0
        else:
            conf = confidence_score(query)  # Fallback to length-based
        
        if tracer:
            conf_step = tracer.start_step("confidence_scoring")
            tracer.finish_step(
                conf_step,
                input_preview=query[:120],
                output_preview=f"Confidence: {conf:.2f}",
                status="ok"
            )
        
        # Log knowledge gaps if confidence is low (optional, fails gracefully)
        if conf < 0.5:
            try:
                log_gap(user_id, topic, conf)
            except Exception:
                pass  # Gap logging is optional
        
        if tracer:
            tracer.end(final_status="ok")
        
        return {
            "request_id": rid,
            "user_id": user_id,
            "answer": answer,
            "citations": citations,
            "topic": topic,
            "safety": safety_status,
            "confidence": round(conf, 2)
        }
    except Exception as e:
        error_msg = str(e)
        if tracer:
            try:
                error_step = tracer.start_step("error_handling")
                tracer.finish_step(
                    error_step,
                    input_preview=query[:120] if query else "",
                    output_preview=error_msg[:120],
                    status="error",
                    error_type=type(e).__name__,
                    error_message=error_msg
                )
                tracer.end(final_status="error", root_cause=error_msg)
            except Exception:
                pass  # Tracing failed, continue anyway
        
        return {
            "request_id": rid,
            "user_id": user_id,
            "status": "failed",
            "error": error_msg,
            "topic": tag_query(query) if query else "General",
            "citations": [],
            "answer": f"I encountered an error: {error_msg}",
            "confidence": 0.0
        }

def run_create_ticket(query: str, user_id: str):
    """Deprecated: Ticketing is disabled in chatbot-only mode."""
    return {"status": "disabled", "message": "ticketing removed"}

