import json, os

GAP_LOG = "backend/logs/knowledge_gaps.json"

def log_gap(user_id: str, topic: str, confidence: float):
    """Record a gap (low confidence or missing knowledge)."""
    os.makedirs(os.path.dirname(GAP_LOG), exist_ok=True)
    entry = {"user_id": user_id, "topic": topic, "confidence": confidence}
    with open(GAP_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")

def summarize_gaps(user_id: str):
    """Return simple frequency of low-confidence topics per user."""
    if not os.path.exists(GAP_LOG):
        return {}
    topics = {}
    with open(GAP_LOG, "r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            if rec["user_id"] == user_id:
                topics[rec["topic"]] = topics.get(rec["topic"], 0) + 1
    return topics
