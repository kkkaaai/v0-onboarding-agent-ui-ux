import os
from dotenv import load_dotenv
load_dotenv()

OPENAI_API_KEY = "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"
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-4o-mini")
TEMPERATURE = float(os.getenv("TEMPERATURE", 0.2))
KB_VERSION = os.getenv("KB_VERSION", "2025-11-02")
