import os, json
import redis
from dotenv import load_dotenv

load_dotenv()
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379")

try:
    rds = redis.Redis.from_url(REDIS_URL)
except Exception:
    rds = None

def save_context(session_id: str, message: dict):
    """Append message to session memory (short-term)."""
    if not rds: return
    key = f"session:{session_id}"
    rds.rpush(key, json.dumps(message))

def get_context(session_id: str, limit=5):
    """Retrieve last N messages for continuity."""
    if not rds: return []
    key = f"session:{session_id}"
    msgs = rds.lrange(key, -limit, -1)
    return [json.loads(m) for m in msgs]
