# agent/retriever.py
import os, json, pickle
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_core.documents import Document
from backend.agent.config import OPENAI_API_KEY

class KnowledgeBase:
    def __init__(self):
        # Validate API key
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is not set. Please check your .env file.")
        
        # Configure embeddings
        embedding_kwargs = {
            "api_key": OPENAI_API_KEY,
            "model": "text-embedding-3-small"
        }
        
        self.embeddings = OpenAIEmbeddings(**embedding_kwargs)
        self.db = None
        self.index_dir = "backend/vector_store"
        self.index_file = os.path.join(self.index_dir, "faiss_index.pkl")
        self.meta_file = os.path.join(self.index_dir, "metadata.json")

    def load(self):
        """Load FAISS index if available, otherwise create a mock one."""
        # Try to load FAISS index if it exists
        if os.path.exists(self.index_file):
            try:
                with open(self.index_file, "rb") as f:
                    self.db = pickle.load(f)
                
                # Check if it's a valid FAISS index
                if hasattr(self.db, "similarity_search_with_score"):
                    # Valid FAISS index loaded
                    return self.db
            except Exception as e:
                print(f"⚠️ Could not load FAISS index: {e}")
                self.db = None
        
        # If we get here, create mock DB (works without FAISS or if FAISS failed)
        print("ℹ️ Using smart mock search (FAISS not available)")
        
        class MockDB:
            def similarity_search_with_score(self, query, k=3):
                """Smart mock search: scores based on keyword matching."""
                from random import random
                query_lower = query.lower() if query else ""
                
                # Load metadata.json if it exists
                meta_path = "backend/vector_store/metadata.json"
                if os.path.exists(meta_path):
                    try:
                        with open(meta_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        chunks = data.get("chunks", [])
                    except Exception:
                        chunks = []
                else:
                    chunks = []
                
                # If no chunks, return empty response
                if not chunks:
                    return []
                
                results = []
                
                # Score chunks based on keyword matching
                for ch in chunks:
                    content = ch.get("content", "").lower()
                    
                    # Simple relevance: count matching keywords
                    query_words = set(query_lower.split())
                    content_words = set(content.split())
                    matches = len(query_words & content_words)
                    
                    # Base score from keyword matching
                    if matches > 0:
                        base_score = min(0.9, 0.5 + (matches * 0.1))
                    else:
                        base_score = 0.3
                    
                    score = round(base_score + random() * 0.15, 2)
                    
                    doc = Document(
                        page_content=ch.get("content", ""),
                        metadata={"source": ch.get("source", "unknown")}
                    )
                    results.append((doc, score))
                
                # Sort by score and return top k
                results.sort(key=lambda x: x[1], reverse=True)
                return results[:k]
        
        self.db = MockDB()
        return self.db


    def search(self, query: str, k: int = 3):
        if not self.db:
            self.load()
        return self.db.similarity_search_with_score(query, k=k)

    def build_index(self, data_dir: str = "backend/data"):
        """
        Create FAISS index from all text/pdf files in the data_dir.
        Saves faiss_index.pkl and metadata.json into backend/vector_store/.
        """
        import glob
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        from langchain_core.documents import Document
        from langchain_community.document_loaders import TextLoader, PyPDFLoader

        # Validate API key
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY is not set. Please check your .env file.")
        
        # Create a fresh embeddings instance for indexing to avoid any state issues
        embedding_kwargs = {
            "api_key": OPENAI_API_KEY,
            "model": "text-embedding-3-small"
        }
        
        embeddings = OpenAIEmbeddings(**embedding_kwargs)
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)

        docs = []
        for path in glob.glob(os.path.join(data_dir, "**/*"), recursive=True):
            if os.path.isdir(path):
                continue
            if path.lower().endswith(".txt"):
                try:
                    loader = TextLoader(path, encoding="utf-8")
                    loaded_docs = loader.load()
                    split_docs = text_splitter.split_documents(loaded_docs)
                    # Filter out invalid documents
                    docs.extend([d for d in split_docs if d.page_content and d.page_content.strip()])
                except Exception as e:
                    print(f"⚠️ Skipped text file {path}: {e}")
            elif path.lower().endswith(".pdf"):
                try:
                    loader = PyPDFLoader(path)
                    loaded_docs = loader.load()
                    split_docs = text_splitter.split_documents(loaded_docs)
                    # Filter out invalid documents
                    docs.extend([d for d in split_docs if d.page_content and d.page_content.strip()])
                except Exception as e:
                    print(f"⚠️ Skipped PDF {path}: {e}")

        if not docs:
            raise ValueError(f"No documents found in {data_dir}")

        # Ensure all docs are proper Document objects
        valid_docs = []
        for doc in docs:
            if hasattr(doc, 'page_content') and hasattr(doc, 'metadata'):
                if doc.page_content and doc.page_content.strip():
                    valid_docs.append(doc)
        
        if not valid_docs:
            raise ValueError("No valid documents after filtering")

        print(f"📄 Processing {len(valid_docs)} document chunks...")
        
        # Debug: Verify document structure
        if len(valid_docs) > 0:
            sample_doc = valid_docs[0]
            print(f"📋 Sample doc type: {type(sample_doc)}, has page_content: {hasattr(sample_doc, 'page_content')}, has metadata: {hasattr(sample_doc, 'metadata')}")
        
        # Test embeddings with a small sample first
        try:
            print("🧪 Testing embeddings API with a sample document...")
            test_text = valid_docs[0].page_content[:100] if valid_docs else "test"
            test_embedding = embeddings.embed_query(test_text)
            print(f"✅ Embeddings API test successful (vector dim: {len(test_embedding)})")
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Embeddings API test failed: {error_msg}")
            if "API key" in error_msg or "authentication" in error_msg.lower():
                raise ValueError(f"OpenAI API authentication failed. Please check your OPENAI_API_KEY. Error: {error_msg}")
            elif "rate limit" in error_msg.lower():
                raise ValueError(f"OpenAI API rate limit exceeded. Please try again later. Error: {error_msg}")
            else:
                raise ValueError(f"Failed to connect to OpenAI API. Error: {error_msg}")
        
        try:
            print("🏗️ Building FAISS index...")
            db = FAISS.from_documents(valid_docs, embeddings)
        except Exception as e:
            error_msg = str(e)
            print(f"❌ Error creating FAISS index: {error_msg}")
            print(f"   Document types: {[type(d).__name__ for d in valid_docs[:5]]}")
            
            # Provide helpful error messages for common issues
            if "AttributeError" in error_msg and "data" in error_msg:
                raise ValueError(
                    f"OpenAI API returned an unexpected response format. "
                    f"This may indicate an API error or version compatibility issue. "
                    f"Original error: {error_msg}"
                )
            raise

        # persist
        os.makedirs(self.index_dir, exist_ok=True)
        with open(self.index_file, "wb") as f:
            pickle.dump(db, f)

        # Use valid_docs for metadata to ensure consistency
        meta = {"size": len(valid_docs), "sources": [d.metadata.get("source") for d in valid_docs if d.metadata]}
        with open(self.meta_file, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)

        print(f"✅ Indexed {len(valid_docs)} docs → {self.index_file}")
        self.db = db
        return db
