# api/main.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uuid, time

from backend.agent.orchestrator import run_docs_search
from backend.agent.config import MODEL_NAME, KB_VERSION
from backend.agent.retriever import KnowledgeBase

app = FastAPI(title="Onboarding Agent", version="0.1.0")

# CORS so ANAM/frontends can hit the API during local dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ToolRequest(BaseModel):
    query: str | None = None
    user_id: str | None = None
    params: dict | None = None

@app.on_event("startup")
def warmup():
    """Preload knowledge base if available, but don't fail if missing."""
    try:
        kb = KnowledgeBase()
        kb.load()
        print("🔥 Vector store preloaded")
    except FileNotFoundError:
        print("⚠️ Vector index not found - will use mock fallback at runtime")
    except Exception as e:
        print(f"⚠️ Vector store preload skipped: {e}")
        print("   Will use mock fallback at runtime")

@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL_NAME, "kb_version": KB_VERSION}

@app.post("/tools/search_docs")
async def search_docs(body: ToolRequest):
    """Search company documentation with RAG."""
    query = body.query or ""
    user_id = body.user_id or "anon"
    
    try:
        data = run_docs_search(query=query, user_id=user_id)
        # Ensure request_id is set
        if "request_id" not in data:
            data["request_id"] = str(uuid.uuid4())
        return data
    except Exception as e:
        # Always return valid JSON, never crash
        return {
            "request_id": str(uuid.uuid4()),
            "status": "failed",
            "error": str(e),
            "answer": "I encountered an error. Please try again.",
            "citations": [],
            "topic": "General",
            "confidence": 0.0
        }

@app.post("/tools/create_ticket")
async def create_ticket(body: ToolRequest):
    """Create a support ticket for IT/HR/Security/Engineering."""
    params = body.params or {}
    user_id = body.user_id or "anon"
    
    try:
        data = run_create_ticket(params=params, user_id=user_id)
        # Ensure request_id is set
        if "request_id" not in data:
            data["request_id"] = str(uuid.uuid4())
        return data
    except Exception as e:
        # Always return valid JSON, never crash
        return {
            "request_id": str(uuid.uuid4()),
            "status": "failed",
            "error": str(e),
            "ticket_id": None,
            "topic": "General"
        }

@app.get("/trace/{request_id}")
async def get_trace(request_id: str):
    """Get trace information for a request."""
    from backend.core.trace.storage import read_trace
    traces = list(read_trace(request_id))
    if not traces:
        raise HTTPException(status_code=404, detail="Trace not found")
    return traces[-1]  # Return most recent trace

class ChatIn(BaseModel):
    user_id: str
    query: str

@app.post("/chat")
async def chat(req: ChatIn):
    try:
        out = run_docs_search(req.query, req.user_id)
        return out
    except Exception as e:
        return {
            "request_id": str(uuid.uuid4()),
            "status": "failed",
            "error": str(e)
        }
