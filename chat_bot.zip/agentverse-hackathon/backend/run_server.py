"""
Simple script to run the FastAPI server.
Run this from the project root: python backend/run_server.py
Or from project root: python -m backend.run_server
"""
import uvicorn
import sys
import os

# Ensure project root is in Python path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

if __name__ == "__main__":
    uvicorn.run("backend.api.main:app", host="0.0.0.0", port=8787, reload=True)

