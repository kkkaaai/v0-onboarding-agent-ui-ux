import json

def test_trace_file():
    path = "backend/logs/traces.jsonl"
    with open(path, "r", encoding="utf-8") as f:
        lines = [json.loads(l) for l in f if l.strip()]
    assert all("request_id" in l for l in lines)
    print(f"✅ {len(lines)} traces found")
