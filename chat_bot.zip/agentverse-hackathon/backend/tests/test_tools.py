import requests

BASE = "http://localhost:8787"

def test_search_docs():
    payload = {"tool_name": "search_docs", "query": "annual leave", "user_id": "test_user"}
    r = requests.post(f"{BASE}/tools/search_docs", json=payload)
    print("Response:", r.json())
    assert r.status_code == 200

if __name__ == "__main__":
    test_search_docs()
