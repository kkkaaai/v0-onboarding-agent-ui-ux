PEOPLE = {
    "HR": {"name": "HR Team", "email": "hr@company.com"},
    "IT": {"name": "IT Helpdesk", "email": "it@company.com"},
    "Security": {"name": "Security Office", "email": "security@company.com"},
    "Engineering": {"name": "DevOps", "email": "devops@company.com"},
}

def find_contact(topic: str):
    """Return a relevant contact for the given topic."""
    return PEOPLE.get(topic, {"name": "Reception", "email": "info@company.com"})

