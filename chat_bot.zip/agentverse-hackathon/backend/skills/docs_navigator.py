# skills/docs_navigator.py
from backend.agent.retriever import KnowledgeBase
from backend.agent.synthesizer import synthesize_answer

_kb = KnowledgeBase()
_loaded = False

def _ensure_loaded():
    global _loaded
    if not _loaded:
        _kb.load()
        _loaded = True

def answer_with_citations(query: str):
    """Get answer with citations. Works even if FAISS is missing."""
    try:
        _ensure_loaded()
        hits = _kb.search(query, k=3)
        
        # If no hits, return default response
        if not hits:
            return "I couldn't find relevant information. Please contact HR or IT support.", []
        
        answer = synthesize_answer(query, hits)
        citations = []
        for doc, score in hits:
            citations.append({
                "source": doc.metadata.get("source", "document"),
                "page": doc.metadata.get("page"),
                "score": float(score),
            })
        return answer, citations
    except Exception as e:
        # Fail gracefully - return helpful error message
        return f"I encountered an error while searching: {str(e)}. Please try again or contact support.", []
