TOPIC_KEYWORDS = {
    "HR": ["leave", "holiday", "benefit", "payroll", "pto", "vacation"],
    "IT": ["vpn", "password", "email", "laptop", "software", "account"],
    "Security": ["gdpr", "privacy", "access", "security", "2fa"],
    "Engineering": ["deploy", "branch", "build", "repo", "merge", "ci"],
}

def tag_query(query: str):
    q = (query or "").lower()
    for topic, kws in TOPIC_KEYWORDS.items():
        if any(k in q for k in kws):
            return topic
    return "General"

def confidence_score(query: str):
    """Very basic confidence proxy: longer query = lower confidence."""
    n = len(query.split())
    return round(max(0.1, min(1.0, 1.5 / (n if n else 1))), 2)
