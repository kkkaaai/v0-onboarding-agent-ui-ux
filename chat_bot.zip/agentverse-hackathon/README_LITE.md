# Onboarding Chatbot (Standalone, No Anam)

A lightweight onboarding **chatbot** with:
- Offline **mock mode** (no API keys required) for demos
- Optional **OpenAI mode** if `OPENAI_API_KEY` is set
- Transparent tracing to `backend/logs/traces.jsonl`
- Works via CLI or FastAPI

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Optional: enable OpenAI (otherwise runs in offline mock mode)
# export OPENAI_API_KEY=sk-...
# export OPENAI_BASE_URL=  # optional proxy

# (optional) build the KB index from knowledge-base/*
python -m backend.scripts.index_builder

# CLI
python main.py "How do I reset my password?" --user u_001

# API
uvicorn backend.api.main:app --reload --port 8000
# POST /chat { "user_id": "u_001", "query": "How do I set up email?" }
```

## Notes
- Professional tone in offline responses.
- Ticketing is **removed**. This is a pure chatbot.
- Traces are available via `GET /trace/{request_id}`.
