const API_URL = "http://127.0.0.1:8000/chat";
const chatContainer = document.getElementById("chat-container");
const input = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

function appendMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  div.textContent = text;
  chatContainer.appendChild(div);

  const ts = document.createElement("div");
  ts.className = "timestamp";
  ts.textContent = new Date().toLocaleTimeString();
  chatContainer.appendChild(ts);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function showTyping() {
  const typing = document.createElement("div");
  typing.id = "typing";
  typing.className = "typing";
  typing.innerHTML = `<span>Assistant is typing</span><span class="dot">.</span><span class="dot">.</span><span class="dot">.</span>`;
  chatContainer.appendChild(typing);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById("typing");
  if (t) t.remove();
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;

  appendMessage("user", text);
  input.value = "";
  showTyping();

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: "demo_user", query: text })
    });
    const data = await res.json();
    removeTyping();

    const answer = data.answer || "⚠️ Unable to connect to assistant.";
    await typeMessage("assistant", answer);
  } catch (err) {
    removeTyping();
    appendMessage("assistant", "⚠️ Could not reach the server.");
  }
}

async function typeMessage(role, text) {
  const div = document.createElement("div");
  div.className = `message ${role}`;
  chatContainer.appendChild(div);
  for (let i = 0; i < text.length; i++) {
    div.textContent = text.slice(0, i + 1);
    chatContainer.scrollTop = chatContainer.scrollHeight;
    await new Promise(r => setTimeout(r, 10));
  }
  const ts = document.createElement("div");
  ts.className = "timestamp";
  ts.textContent = new Date().toLocaleTimeString();
  chatContainer.appendChild(ts);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keypress", e => {
  if (e.key === "Enter") sendMessage();
});
