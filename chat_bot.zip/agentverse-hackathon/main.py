# main.py
import argparse, json
from datetime import datetime
from backend.agent.orchestrator import run_docs_search

def _parse():
    ap = argparse.ArgumentParser()
    ap.add_argument("query", nargs="?", default="How do I set up my laptop and get VPN access?")
    ap.add_argument("--user", default="demo_user")
    return ap.parse_args()

class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

def main():
    args = _parse()
    out = run_docs_search(args.query, args.user)
    print(json.dumps(out, indent=2, cls=DateTimeEncoder))

if __name__ == "__main__":
    main()
